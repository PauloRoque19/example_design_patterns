/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Paulinho
 */
public class Individuo implements Congresso{

    List<Integer> list = new ArrayList<Integer>();
    
    public Individuo() {
    }
    
    public void getAssento(){
        
       list.add(1);
    }

    @Override
    public int totalParticipantes() {
        int contador = 0;
        for(Integer i: list){
            if(i != null){
                contador++;
            }
        }
        return contador;
        
    }

    @Override
    public int totalAcentos() {
         int contador = 0;
        for(Integer i: list){
            if(i != null){
                contador++;
            }
        }
        return contador;
    }
    
}
