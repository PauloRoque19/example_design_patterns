/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author Paulinho
 */
public class Instituicao implements Congresso{
    
    ArrayList<Individuo> Congresso = new ArrayList();

    public Instituicao() {
    }
    
    
    public void getMembros(Individuo i){
          Congresso.add(i);
    }

    @Override
    public int totalParticipantes() {
        int contador = 0;
        for(Individuo i: Congresso){
            if(i != null){
                contador++;
            }
        }
        return contador;
    }

    @Override
    public int totalAcentos() {
       int contador = 0;
        for(Individuo i: Congresso){
            if(i != null){
                contador++;
            }
        }
        return contador;
    }
}
