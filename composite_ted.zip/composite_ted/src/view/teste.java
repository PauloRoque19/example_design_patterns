/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import model.Congresso;
import model.Individuo;
import model.Instituicao;

/**
 *
 * @author Paulinho
 */
public class teste {
    public static void main(String[] args) {
        System.out.println("Quantidade de Pessoas na Palestra e assentos");
        Individuo individuo = new Individuo();
        individuo.getAssento();
        System.out.println(individuo.totalParticipantes());
        System.out.println(individuo.totalAcentos());
        System.out.println("----------------------------------------");
        Individuo aluno0 = new Individuo();
        Individuo aluno1 = new Individuo();
        Individuo aluno2 = new Individuo();
        Individuo aluno3 = new Individuo();
        Individuo aluno4 = new Individuo();
        Individuo aluno5 = new Individuo();
        Individuo aluno6 = new Individuo();
        
        System.out.println("Quantidade de Pessoas da IESP na Palestra e assentos");
        Instituicao iesp = new Instituicao();
        iesp.getMembros(aluno0);
        iesp.getMembros(aluno1);
        iesp.getMembros(aluno2);
        iesp.getMembros(aluno3);
        iesp.getMembros(aluno4);
        iesp.getMembros(aluno5);
        iesp.getMembros(aluno6);
        
        System.out.println(iesp.totalParticipantes());
        System.out.println(iesp.totalAcentos());
        System.out.println("---------------------------------------------------");
        
        
        
        
        
        //Congresso congresso2 = new Instituicao();
        //System.out.println(congresso2.totalAcentos(7));
        
        
    }
    
    
}
