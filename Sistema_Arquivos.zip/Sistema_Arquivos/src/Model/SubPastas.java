/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author Paulinho
 */
public class SubPastas {
    
    ArrayList<Arquivos> listaSub = new ArrayList();
    protected Arquivos arq;

    public SubPastas(Arquivos arq) {
        this.arq = arq;
    }
    
    
    public void adicionarArq(Arquivos arq){
        listaSub.add(arq);
    }

    @Override
    public String toString() {
        return "SubPastas{" + "listaSub=" + listaSub + ", arq=" + arq + '}';
    }
    
    
}
