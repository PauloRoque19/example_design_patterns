/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Paulinho
 */
public class Mp3 extends Arquivos{

    public Mp3(String nome, String tamanho) {
        super(nome, tamanho);
    }

    @Override
    public String toString() {
        return "Nome Arquivo"+this.getNome() + " "+ "Tamanho do Arquivo"+ this.getTamanho();
    }
    
    
    
}
