/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author Paulinho
 */
public class Pastas {
    
   ArrayList<Pastas> listaPast = new ArrayList();
    
    protected Arquivos arq;
    protected SubPastas subP;
    private String nome;

    public Pastas(Arquivos arq, SubPastas subP, String nome) {
        this.arq = arq;
        this.subP = subP;
        this.nome = nome;
    }
   
    
    public void adicionarF(Pastas p){
        listaPast.add(p);
    }

    @Override
    public String toString() {
        return "Pastas{" + "arq=" + arq + ", subP=" + subP + ", nome=" + nome + '}';
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
}
