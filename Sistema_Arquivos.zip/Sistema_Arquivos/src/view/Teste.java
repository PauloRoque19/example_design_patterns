/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import Model.Arquivos;
import Model.Imagem;
import Model.Mp3;
import Model.Pastas;
import Model.SubPastas;

/**
 *
 * @author Paulinho
 */
public class Teste {
    
    public static void main(String[] args) {
        
    
    Arquivos music1 = new Mp3("BIP","1kb");
    Arquivos img1 = new Imagem("Passaros", "2kb");
    Arquivos img2 = new Imagem("Flores", "2kb");
    SubPastas sub1 =  new SubPastas(img1);
    sub1.adicionarArq(img2);
    Pastas pasta = new Pastas(music1 , sub1, "Nova Pasta 1");
    pasta.adicionarF(pasta);
        System.out.println(pasta.toString());
    
}
    
}
