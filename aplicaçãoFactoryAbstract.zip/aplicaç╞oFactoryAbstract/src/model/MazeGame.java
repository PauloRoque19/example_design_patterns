/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Paulinho
 */
public class MazeGame {
    
    private AbstractRoom quarto;
    private AbstractWall parede;
    private AbstractDoor porta;
    
    
    public MazeGame() {
    }

    public AbstractRoom getQuarto() {
        return quarto;
    }

    public void setQuarto(AbstractRoom quarto) {
        this.quarto = quarto;
    }

    public AbstractWall getParede() {
        return parede;
    }

    public void setParede(AbstractWall parede) {
        this.parede = parede;
    }

    public AbstractDoor getPorta() {
        return porta;
    }

    public void setPorta(AbstractDoor porta) {
        this.porta = porta;
    }
    
    
    
    
    public MazeGame criarLabirinto(String tipo){
        AbstractMazeFactory fabrica = null;
        
        if(tipo.equals("labirintocomum")){
            fabrica = new MazeFactory();
        }else if(tipo.equals("labirintoencantado")){
            fabrica = new EnchantedMazeFactory();
        }
        else{
            System.out.println("Labirinto não existente");
        }
        
        MazeGame labirinto = new MazeGame();
        labirinto.setQuarto(fabrica.makeRoom());
        labirinto.setParede(fabrica.makeWall());
        labirinto.setPorta(fabrica.makeDoor());
        
        return labirinto;
    }
    
}
