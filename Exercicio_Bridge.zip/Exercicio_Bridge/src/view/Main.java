/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import model.Livro;
import model.LivroIMP;
import model.LivroImpXML;
import model.LivroImplBD;
import model.Publicacao;
import model.Revista;
import model.RevistaImplBD;
import model.RevistaImplXML;

/**
 *
 * @author Paulinho
 */
public class Main {
    public static void main(String[] args) {
        
        LivroIMP salvar = new LivroImplBD();
        
        
        Publicacao livro = new Livro(new LivroImpXML());
        System.out.println(livro.save());
        
        System.out.println("");
        Publicacao revista = new Revista(new RevistaImplBD());
        System.out.println(revista.save());
        
    }
}
