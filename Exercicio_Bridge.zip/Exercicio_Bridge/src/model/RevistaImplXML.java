/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Paulinho
 */
public class RevistaImplXML implements RevistaIMP{

    public RevistaImplXML() {
    }

    
    
    
    @Override
    public String save() {
        return "Revista Salva em XML";    
    }
    
}
