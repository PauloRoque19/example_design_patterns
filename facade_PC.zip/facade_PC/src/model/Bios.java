/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Paulinho
 */
public class Bios {

    private Processor processador;
    private Ssd ssd;
    private MemoryRam memoria;
    
    
    
    public Bios(){
        processador = new Processor();
        ssd = new Ssd();
        memoria = new MemoryRam();
    }
    
    public void processador(){
        processador.start();
        processador.execute();
        processador.free();
        processador.load();
            
        
    }
    
    public void ssd(){
        ssd.read();
        ssd.write();
    }
    
    public void memoria(){
        memoria.free();
        memoria.load();
    }
    
    
}
