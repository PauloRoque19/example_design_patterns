/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Paulinho
 */
public class Processor {

    public Processor() {
    }
    
    public void start(){
        System.out.println("Starting CPU");
    }
    
    public void execute(){
        System.out.println("Executing CPU");
    }
    
    public void load(){
        System.out.println("Uso: 62%");
    }
    public void free(){
        System.out.println("Reserva: 38%");
    }
}
