/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Paulinho
 */
public class Ssd {

    public Ssd() {
    }
    
    public void write(){
        System.out.println("Ssd: 150,01-Mb/s");
    }
    public void read(){
        System.out.println("Ssd: 143,15-Mb/s");
    }
}
