/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Paulinho
 */
public class MemoryRam {

    public MemoryRam() {
    }
    
    public void load(){
        System.out.println("Ram: 4,5 mb");
    }
    
    public void free(){
        System.out.println("Ram: 3,5mb");
    }
    
}
