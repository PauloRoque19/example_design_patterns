/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import Model.AbstracaoTamanho;
import Model.CocaCola;
import Model.Guarana;
import Model.TamanhoGrande;
import Model.TamanhoMedio;
import Model.TamanhoPequeno;

/**
 *
 * @author Paulinho
 */
public class Teste {
    public static void main(String[] args) {
        
    AbstracaoTamanho pequeno = new TamanhoPequeno(new CocaCola());
    AbstracaoTamanho medio = new TamanhoMedio(new CocaCola());
    AbstracaoTamanho grande  = new TamanhoGrande(new CocaCola());
    
    pequeno.beber();
    medio.beber();
    grande.beber();
    
     pequeno = new TamanhoPequeno(new Guarana());
     medio = new TamanhoMedio(new Guarana());
     grande  = new TamanhoGrande(new Guarana());
     
    pequeno.beber();
    medio.beber();
    grande.beber();
    
    }
}
